# Ordem de Compra Inteligente - Backend (Etapa 1)

Este projeto simula a lógica de detecção de produtos sob encomenda com base no SKU que contém "PEDIDO".

## Como rodar

1. Instale as dependências:
```
npm install
```

2. Inicie o servidor:
```
npm start
```

3. Acesse:
```
http://localhost:3000/gerar-oc
```
